#/usr/bin/env bash
complete -W "upload move" orb
