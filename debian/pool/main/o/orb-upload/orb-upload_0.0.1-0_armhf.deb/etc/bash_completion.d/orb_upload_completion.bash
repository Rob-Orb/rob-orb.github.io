#/usr/bin/env bash
complete -W "motor" upload
