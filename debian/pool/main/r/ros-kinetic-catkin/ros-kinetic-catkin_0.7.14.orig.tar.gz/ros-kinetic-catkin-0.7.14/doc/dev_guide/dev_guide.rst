Developers Guide
================

This section of the documentation is provided for developers of
catkin itself.

.. toctree::
   :maxdepth: 2

   sketch
   layout
   code_generation
   generated_cmake_api
   maintainer
   api/index
