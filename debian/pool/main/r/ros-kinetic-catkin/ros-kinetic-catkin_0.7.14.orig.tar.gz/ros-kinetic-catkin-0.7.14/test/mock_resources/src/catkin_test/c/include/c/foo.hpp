#pragma once
namespace c {
  void foo();
}

