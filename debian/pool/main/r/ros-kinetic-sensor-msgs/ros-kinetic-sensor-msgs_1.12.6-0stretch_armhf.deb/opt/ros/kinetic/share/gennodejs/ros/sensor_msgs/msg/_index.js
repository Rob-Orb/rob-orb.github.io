
"use strict";

let TimeReference = require('./TimeReference.js');
let Temperature = require('./Temperature.js');
let ChannelFloat32 = require('./ChannelFloat32.js');
let PointCloud = require('./PointCloud.js');
let FluidPressure = require('./FluidPressure.js');
let NavSatStatus = require('./NavSatStatus.js');
let Illuminance = require('./Illuminance.js');
let Imu = require('./Imu.js');
let MultiEchoLaserScan = require('./MultiEchoLaserScan.js');
let Joy = require('./Joy.js');
let PointCloud2 = require('./PointCloud2.js');
let JoyFeedbackArray = require('./JoyFeedbackArray.js');
let NavSatFix = require('./NavSatFix.js');
let LaserScan = require('./LaserScan.js');
let MagneticField = require('./MagneticField.js');
let Range = require('./Range.js');
let PointField = require('./PointField.js');
let LaserEcho = require('./LaserEcho.js');
let JointState = require('./JointState.js');
let Image = require('./Image.js');
let RelativeHumidity = require('./RelativeHumidity.js');
let JoyFeedback = require('./JoyFeedback.js');
let MultiDOFJointState = require('./MultiDOFJointState.js');
let CameraInfo = require('./CameraInfo.js');
let CompressedImage = require('./CompressedImage.js');
let BatteryState = require('./BatteryState.js');
let RegionOfInterest = require('./RegionOfInterest.js');

module.exports = {
  TimeReference: TimeReference,
  Temperature: Temperature,
  ChannelFloat32: ChannelFloat32,
  PointCloud: PointCloud,
  FluidPressure: FluidPressure,
  NavSatStatus: NavSatStatus,
  Illuminance: Illuminance,
  Imu: Imu,
  MultiEchoLaserScan: MultiEchoLaserScan,
  Joy: Joy,
  PointCloud2: PointCloud2,
  JoyFeedbackArray: JoyFeedbackArray,
  NavSatFix: NavSatFix,
  LaserScan: LaserScan,
  MagneticField: MagneticField,
  Range: Range,
  PointField: PointField,
  LaserEcho: LaserEcho,
  JointState: JointState,
  Image: Image,
  RelativeHumidity: RelativeHumidity,
  JoyFeedback: JoyFeedback,
  MultiDOFJointState: MultiDOFJointState,
  CameraInfo: CameraInfo,
  CompressedImage: CompressedImage,
  BatteryState: BatteryState,
  RegionOfInterest: RegionOfInterest,
};
