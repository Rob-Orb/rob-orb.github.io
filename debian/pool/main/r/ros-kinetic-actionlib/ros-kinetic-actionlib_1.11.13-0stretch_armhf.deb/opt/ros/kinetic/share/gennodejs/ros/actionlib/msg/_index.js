
"use strict";

let TestGoal = require('./TestGoal.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TestActionFeedback = require('./TestActionFeedback.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TestActionResult = require('./TestActionResult.js');
let TestActionGoal = require('./TestActionGoal.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TestAction = require('./TestAction.js');
let TestRequestResult = require('./TestRequestResult.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TestResult = require('./TestResult.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TestRequestAction = require('./TestRequestAction.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TestFeedback = require('./TestFeedback.js');

module.exports = {
  TestGoal: TestGoal,
  TestRequestGoal: TestRequestGoal,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TwoIntsAction: TwoIntsAction,
  TestActionFeedback: TestActionFeedback,
  TestRequestActionResult: TestRequestActionResult,
  TwoIntsFeedback: TwoIntsFeedback,
  TestActionResult: TestActionResult,
  TestActionGoal: TestActionGoal,
  TestRequestFeedback: TestRequestFeedback,
  TwoIntsResult: TwoIntsResult,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TestAction: TestAction,
  TestRequestResult: TestRequestResult,
  TwoIntsGoal: TwoIntsGoal,
  TestResult: TestResult,
  TwoIntsActionResult: TwoIntsActionResult,
  TestRequestActionGoal: TestRequestActionGoal,
  TestRequestAction: TestRequestAction,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TestFeedback: TestFeedback,
};
